class KnightPathFinder

  def initialize
    
  end
end
